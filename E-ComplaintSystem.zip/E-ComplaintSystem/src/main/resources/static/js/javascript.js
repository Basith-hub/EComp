function validateform(){
	var username = document.getElementById("uname").value;
	var password = document.getElementById("upassword").value;
	if(username==""||password==""){
	            return false;
			}
}
function validateusercomplaintform(){
	var complaint = document.getElementById("complaint").value;

	if(complaint == ""){
	            return false;
			}
}
function validateuserviewform(){
	var complaintId = document.getElementById("complaintId").value;

	if(complaintId == ""){
	            return false;
			}
}