package com.EComplaintSystem.controller;

import java.sql.SQLException;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.EComplaintSystem.database.Database;
import com.EComplaintSystem.model.login;
import com.EComplaintSystem.service.ServiceInterface;
import com.EComplaintSystem.model.complaint;

@org.springframework.stereotype.Controller
public class Controller {

	
	@Autowired
	private Database d;
	@Autowired
	private ServiceInterface service;
	
	@RequestMapping(value="/home",method = RequestMethod.GET)
	public String homepage(@ModelAttribute("lg") login lg) {
		return "homepage";
	}
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public String userlogin(@ModelAttribute("lg") login lg,BindingResult result,ModelMap model) throws ClassNotFoundException, SQLException {
		
		boolean b = d.checkUser(lg);
		model.addAttribute("complaint", new complaint(null,null,null,null,null,null));
		if (b == true) {
			model.put("user",lg.getUsername());
			return "userpage";
		} else {
			return "loginerrorpage";
		}
		
	}
	@RequestMapping(value="/register",method = RequestMethod.POST)
	public String userregister(@ModelAttribute("lg") login lg,BindingResult result,ModelMap model) throws ClassNotFoundException, SQLException {
		
		model.addAttribute("complaint", new complaint(null,null,null,null,null,null));
		d.insertData(lg);
		model.put("user",lg.getUsername());
		return "userpage";
	}
	
	@RequestMapping(value = "/adminlogin", method = RequestMethod.POST)
	public String showAdminpage(@ModelAttribute("lg") login lg, ModelMap model) throws Exception {
		model.addAttribute("complaint", new complaint(null,null,null,null,null,null));
		if (lg.getUsername().equals("admin") && lg.getPassword().equals("adminlogin")) {
			model.addAttribute("userinfo", service.getComplaints());
			model.addAttribute("userinfoassigned", service.getComplaints());
			return "adminpage";
		} else {
			return "adminerrorpage";
		}
	}
	@RequestMapping(value = "/addComplaint", method = RequestMethod.POST)
	public String addComplaint(@ModelAttribute("complaint") complaint complaint, ModelMap model,@RequestParam String user) throws Exception {
		service.addComplaint(complaint,user);
		String complaintid = d.getcomplaintIdbyName(user);
		model.addAttribute("showid",true);
		model.put("complaintid",complaintid);
		return "userpage";
	}
	
	@RequestMapping(value = "/viewcomplaintstatus", method = RequestMethod.POST)
	public String viewComplaintStatus(@ModelAttribute("complaint") complaint complaint, ModelMap model) throws ClassNotFoundException, SQLException {
		String status = service.viewComplaintstatus(complaint.getComplaintid());
		model.addAttribute("showstatus", true);
		model.put("status", status);
		return "userpage";
	}
	@RequestMapping(value = "/Assigning", method = RequestMethod.POST)
	public String assigning(@ModelAttribute("complaint") complaint complaint, ModelMap model,@RequestParam String complaintid,@RequestParam String status,@RequestParam(required = false) String priority) throws ClassNotFoundException, SQLException {
		String Status=null;
		String Priority = null;
		if(status.contains("Closed")) {
			Status = "Closed";
		}else {
			Status = "Open";
		}
		if(priority!=null) {
		if(priority.contains("Medium")) {
			Priority = "Medium";
		}
		else if(priority.contains("High")) {
			Priority = "High";
		}
		else {
			Priority ="Low";
		}
		}
		d.updatecomplaint(complaintid,Status,Priority);
		
		model.addAttribute("userinfo", service.getComplaints());
		return "adminpage";
	}
}
