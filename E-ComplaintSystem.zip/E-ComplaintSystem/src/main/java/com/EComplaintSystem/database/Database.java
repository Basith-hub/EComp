package com.EComplaintSystem.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;

import com.EComplaintSystem.model.complaint;
import com.EComplaintSystem.model.login;




@Component
public class Database {

	public boolean checkUser(login lg) throws ClassNotFoundException, SQLException {
		boolean b=false;
		List<login> l =getUser();
		for(login l1:l) {
			if(l1.getUsername().equals(lg.getUsername())&& l1.getPassword().equals(lg.getPassword())) {
				b=true;
				break;
			}
		}
		
		return b;
		
	}

	private List<login> getUser() throws ClassNotFoundException, SQLException {
		List<login> login2 = new ArrayList<>();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		java.sql.Statement stmnt = c.createStatement();
		ResultSet rs = stmnt.executeQuery("select username,password from user");
		while (rs.next()) {
			String username = rs.getString(1);
			String password = rs.getString(2);
			login l = new login(username, password);
			login2.add(l);

		}
		return login2;
	}


	public void insertData(login lg) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		PreparedStatement ps = c.prepareStatement("insert into user(username,password) values(?,?)");
		ps.setString(1, lg.getUsername());
		ps.setString(2, lg.getPassword());
		ps.execute();
		
	}

	public void addComplaint(complaint complaint,String user) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		PreparedStatement ps = c.prepareStatement("update user set complaintid =?,complaints =?,status=?,priority=?,confirm=? where username=?");
		Random random = new Random();
		int id = 1;
		id=	100000 + random.nextInt(900000);	
		List<String> complaintIds = new ArrayList<>();
		complaintIds = getComplaintid();
		while(complaintIds.contains(Integer.toString(id))) {
			id= 100000 + random.nextInt(900000);
			
		}
		ps.setString(2,complaint.getComplaints());
		ps.setString(1, Integer.toString(id));
		ps.setString(3, "Open");
		ps.setString(4, "Low");
		ps.setBoolean(5, false);
		ps.setString(6,user);
		ps.execute();
		
	}

	private List<String> getComplaintid() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		List<String> list = new ArrayList<>();
		PreparedStatement ps = c.prepareStatement("select complaintid from user");
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			list.add(rs.getString(1));
		}
		return list;
	}

	public List<complaint> getComplaints() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		Statement stmt = c.createStatement();	
		ResultSet rs = stmt.executeQuery("Select complaintid,username,complaints,status, priority,confirm from user where status = \"Open\"");
		List<complaint> list = new ArrayList<>();
		while(rs.next()) {
			complaint cp = new complaint(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getBoolean(6));
			list.add(cp);
		}
		return list;
		
	}

	public String getcomplaintIdbyName(String user) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		PreparedStatement ps = c.prepareStatement("select complaintid from user where username=?");
		ps.setString(1, user);
		ResultSet rs = ps.executeQuery();
		String id = null;
		while(rs.next()) {
			id = rs.getString(1);
		}
		return id;
	}

	public String getstatus(String complaintid) throws ClassNotFoundException, SQLException  {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		PreparedStatement ps = c.prepareStatement("select status from user where complaintid=?");
		ps.setString(1, complaintid);
		ResultSet rs = ps.executeQuery();
		String status = null;
		while(rs.next()) {
			status = rs.getString(1);
		}
		return status;
	}

	public void updatecomplaint(String complaintid, String status, String priority) throws ClassNotFoundException, SQLException  {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/EComplaintSystem",
				"root", "root");
		PreparedStatement ps = c.prepareStatement("update user set status =?,priority =?, confirm =?  where complaintid =?");
		ps.setString(1, status);
		ps.setString(2, priority);
		ps.setBoolean(3, true);
		ps.setString(4,complaintid);
		ps.execute();
	}

	
}
