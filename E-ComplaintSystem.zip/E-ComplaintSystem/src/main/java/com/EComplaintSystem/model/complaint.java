package com.EComplaintSystem.model;

public class complaint {

	private String complaintid;
	private String username;
	private String complaints;
	private String status;
	private String priority;
	private Boolean confirm;
	
	public complaint(String complaintid, String username, String complaints, String status, String priority, Boolean confirm) {
		super();
		this.complaintid = complaintid;
		this.username = username;
		this.complaints = complaints;
		this.status = status;
		this.priority = priority;
		this.confirm = confirm;
	}
	public String getComplaintid() {
		return complaintid;
	}
	public void setComplaintid(String complaintid) {
		this.complaintid = complaintid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getComplaints() {
		return complaints;
	}
	public void setComplaints(String complaints) {
		this.complaints = complaints;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Boolean getConfirm() {
		return confirm;
	}
	public void setConfirm(Boolean confirm) {
		this.confirm = confirm;
	}
}