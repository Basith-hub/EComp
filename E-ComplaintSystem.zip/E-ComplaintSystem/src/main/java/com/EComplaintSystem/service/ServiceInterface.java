package com.EComplaintSystem.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.EComplaintSystem.model.complaint;


@Service
public interface ServiceInterface {

     public List<complaint> getComplaints() throws ClassNotFoundException, SQLException ;

	public void addComplaint(complaint complaint,String user) throws ClassNotFoundException, SQLException;

	public String viewComplaintstatus(String complaintid) throws ClassNotFoundException, SQLException;

}
