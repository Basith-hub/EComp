package com.EComplaintSystem.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.EComplaintSystem.database.Database;
import com.EComplaintSystem.model.complaint;


@org.springframework.stereotype.Service
public class Service implements ServiceInterface {
	@Autowired
	private Database d;
	@Override
	public List<complaint> getComplaints() throws ClassNotFoundException, SQLException {
		List<complaint> lg = new ArrayList<>();
		lg = d.getComplaints();
		return lg;
	}

	@Override
	public void addComplaint(complaint complaint,String user) throws ClassNotFoundException, SQLException {
		d.addComplaint(complaint,user);
		
	}

	@Override
	public String viewComplaintstatus(String complaintid) throws ClassNotFoundException, SQLException {
		String status = d.getstatus(complaintid);
		return status;
	}

}
