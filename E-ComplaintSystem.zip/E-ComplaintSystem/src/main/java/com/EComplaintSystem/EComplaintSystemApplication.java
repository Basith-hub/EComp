package com.EComplaintSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class EComplaintSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(EComplaintSystemApplication.class, args);
	}

}
